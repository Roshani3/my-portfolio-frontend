import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Project } from '../../models/portfolio.model';

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="projects" class="section-padding bg-dark">
      <div class="container">
        <div class="row mb-5" data-aos="fade-up">
          <div class="col-12 text-center">
            <h2 class="display-5 mb-3 fw-bold text-white">Featured <span class="text-accent">Projects</span></h2>
            <div class="underline mx-auto"></div>
          </div>
        </div>
        
        <div class="row g-5 justify-content-center">
          <div *ngFor="let project of projects; let i = index" class="col-lg-10" 
               data-aos="fade-up" [attr.data-aos-delay]="i * 150">
            <div class="project-card glass-card overflow-hidden">
              <!-- Top: Cinematic Image Container -->
              <div class="project-image-wrapper">
                <img [src]="project.image" [alt]="project.title" class="project-img">
                <div class="project-overlay">
                  <div class="d-flex gap-3">
                    <a href="https://conference.azurewebsites.net/auth/login" class="btn btn-accent-circle"><i class="bi bi-link-45deg"></i></a>
                  </div>
                </div>
              </div>

              <!-- Bottom: Detailed Content -->
              <div class="project-content p-4 p-md-5">
                <div class="d-flex flex-wrap gap-2 mb-4">
                  <span *ngFor="let tag of project.tags" class="badge-custom">{{tag}}</span>
                </div>
                
                <h3 class="display-6 mb-3 text-white fw-bold">{{project.title}}</h3>
                <p class="text-light-muted fs-5 mb-4 lh-lg">{{project.description}}</p>
                
                <div class="row g-4">
                  <div class="col-md-6" *ngFor="let feature of project.features">
                    <div class="feature-item d-flex align-items-center">
                      <div class="dot me-3"></div>
                      <span class="text-white">{{feature}}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .text-accent { color: #00bcd4; }
    .text-light-muted { color: #cbd5e1; }
    .underline { width: 80px; height: 4px; background: #00bcd4; border-radius: 10px; }

    .project-card {
      border: 1px solid rgba(255, 255, 255, 0.05);
      background: rgba(255, 255, 255, 0.02);
      border-radius: 30px;
      transition: all 0.5s ease;
      &:hover {
        transform: translateY(-10px);
        border-color: rgba(0, 188, 212, 0.3);
        box-shadow: 0 30px 60px rgba(0,0,0,0.4);
      }
    }

    .project-image-wrapper {
      position: relative;
      height: 450px;
      overflow: hidden;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }

    .project-img {
      width: 100%; height: 100%; object-fit: cover;
      transition: transform 1s cubic-bezier(0.165, 0.84, 0.44, 1);
    }

    .project-card:hover .project-img { transform: scale(1.05); }
    .project-overlay {
      position: absolute; inset: 0;
      background: rgba(11, 17, 32, 0.6);
      display: flex; align-items: center; justify-content: center;
      opacity: 0; transition: opacity 0.4s ease;
    }

    .project-card:hover .project-overlay { opacity: 1; }

    .btn-accent-circle {
      width: 60px; height: 60px;
      background: #00bcd4; color: #0b1120;
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      font-size: 1.5rem; transition: all 0.3s ease;
      &:hover { transform: scale(1.1); background: #fff; }
    }
    .badge-custom {
      background: rgba(0, 188, 212, 0.1);
      color: #00bcd4;
      padding: 6px 16px;
      border-radius: 50px;
      font-size: 0.85rem;
      font-weight: 600;
      border: 1px solid rgba(0, 188, 212, 0.2);
    }

    .feature-item {
      padding: 12px 20px;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      .dot { width: 8px; height: 8px; background: #00bcd4; border-radius: 50%; box-shadow: 0 0 10px #00bcd4; }
    }

    @media (max-width: 991px) { .project-image-wrapper { height: 300px; } }
  `]
})
export class ProjectsComponent {
  @Input() projects: Project[] = [];
}