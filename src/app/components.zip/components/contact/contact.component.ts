import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  providers: [ContactService],
  template: `
    <section id="contact" class="section-padding bg-dark-2">
      <div class="container">
        <div class="row mb-5" data-aos="fade-up">
          <div class="col-12 text-center">
            <h2 class="display-5 mb-3 fw-bold text-white">Get In <span class="text-accent">Touch</span></h2>
            <div class="underline mx-auto"></div>
          </div>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-11">
            <div class="glass-card contact-container p-4 p-md-5 overflow-hidden">
              <div class="row g-5">
                <div class="col-md-5" data-aos="fade-right">
                  <h3 class="h4 mb-4 text-white fw-bold">Contact Information</h3>
                  <p class="text-light-muted mb-5 fs-6 lh-lg">I'm currently looking for new opportunities. Whether you have a question or just want to say hi, I'll try my best to get back to you!</p>
                  
                  <div class="contact-methods">
                    <div class="d-flex align-items-center mb-4">
                      <div class="icon-box-accent me-3"><i class="bi bi-envelope-at-fill"></i></div>
                      <div>
                        <h6 class="mb-0 text-white small fw-bold text-uppercase tracking-wider">Email</h6>
                        <p class="text-accent mb-0">{{email}}</p>
                      </div>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                      <div class="icon-box-accent me-3"><i class="bi bi-telephone-fill"></i></div>
                      <div>
                        <h6 class="mb-0 text-white small fw-bold text-uppercase tracking-wider">Mobile</h6>
                        <p class="text-accent mb-0">+91 93226 26117</p>
                      </div>
                    </div>
                  </div>

                  <div class="d-flex gap-3 mt-5">
                    <a [href]="github" target="_blank" class="social-circle-premium"><i class="bi bi-github"></i></a>
                    <a [href]="linkedin" target="_blank" class="social-circle-premium"><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>

                <div class="col-md-7" data-aos="fade-left">
                  <form [formGroup]="contactForm" (ngSubmit)="onSubmit()" class="contact-form">
                    <div class="mb-4">
                      <label class="form-label text-white small fw-bold mb-2">Full Name</label>
                      <input type="text" class="form-control premium-input" placeholder="Enter your name" formControlName="name">
                    </div>
                    <div class="mb-4">
                      <label class="form-label text-white small fw-bold mb-2">Email Address</label>
                      <input type="email" class="form-control premium-input" placeholder="example@gmail.com" formControlName="email">
                    </div>
                    <div class="mb-4">
                      <label class="form-label text-white small fw-bold mb-2">Message</label>
                      <textarea class="form-control premium-input" rows="5" placeholder="Tell me about your inquiry..." formControlName="message"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-accent-gradient w-100 py-3 fw-bold tracking-wider" [disabled]="contactForm.invalid || isSubmitting">
                      <span *ngIf="!isSubmitting">SEND MESSAGE <i class="bi bi-send-fill ms-2"></i></span>
                      <span *ngIf="isSubmitting" class="spinner-border spinner-border-sm" role="status"></span>
                    </button>

                    <div *ngIf="status === 'success'" class="alert alert-success mt-4 glass-alert d-flex align-items-center">
                      <i class="bi bi-check-circle-fill me-2 fs-5"></i> 
                      <span>Thank you! Your message has been sent successfully.</span>
                    </div>

                    <div *ngIf="status === 'error'" class="alert alert-danger mt-4 glass-alert d-flex align-items-center bg-danger-subtle text-danger border-danger">
                      <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i> 
                      <span>Oops! Something went wrong. Please try again later.</span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .bg-dark-2 { background-color: #0b1120; }
    .text-accent { color: #00bcd4; }
    .text-light-muted { color: #cbd5e1; }
    .underline { width: 80px; height: 4px; background: #00bcd4; border-radius: 10px; }
    .tracking-wider { letter-spacing: 0.1rem; }
    .glass-card { background: rgba(255, 255, 255, 0.02); backdrop-filter: blur(15px); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 30px; }
    .icon-box-accent { width: 48px; height: 48px; background: rgba(0, 188, 212, 0.1); color: #00bcd4; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
    .social-circle-premium { width: 50px; height: 50px; background: rgba(255, 255, 255, 0.05); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; border: 1px solid rgba(255, 255, 255, 0.1); transition: all 0.3s ease; }
    .social-circle-premium:hover { background: #00bcd4; color: #0b1120; transform: translateY(-5px); }
    .premium-input { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.08); color: white; padding: 14px 20px; border-radius: 12px; }
    .premium-input:focus { background: rgba(255, 255, 255, 0.05); border-color: #00bcd4; color: white; box-shadow: 0 0 15px rgba(0, 188, 212, 0.1); }
    .btn-accent-gradient { background: linear-gradient(135deg, #00bcd4 0%, #00acc1 100%); color: #0b1120; border-radius: 12px; transition: all 0.3s ease; }
    .btn-accent-gradient:hover:not(:disabled) { transform: translateY(-2px); background: #00e5ff; }
    .glass-alert { background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); color: #10b981; border-radius: 15px; }
  `]
})
export class ContactComponent {
  @Input() email: string = '';
  @Input() github: string = '';
  @Input() linkedin: string = '';

  contactForm: FormGroup;
  isSubmitting = false;
  status: 'idle' | 'success' | 'error' = 'idle';

  constructor(private fb: FormBuilder, private contactService: ContactService) {
    this.contactForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      message: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.contactForm.invalid) {
      this.contactForm.markAllAsTouched();
      return;
    }
  
    this.isSubmitting = true;
    this.status = 'idle';
  
    const formValue = this.contactForm.value;
  
    const payload = {
      name: formValue.name,
      email: formValue.email,
      message: formValue.message,
      subject: `New Portfolio Inquiry from ${formValue.name}`
    };
  
    console.log('Sending payload:', payload); // 🔎 Debug
  
    this.contactService.sendMessage(payload).subscribe({
      next: (response) => {
        console.log('Success response:', response); // 🔎 Debug
        this.status = 'success';
        this.contactForm.reset();
        this.isSubmitting = false;
  
        setTimeout(() => {
          this.status = 'idle';
        }, 5000);
      },
      error: (error) => {
        console.error('Error occurred:', error); // 🔎 Debug
        this.status = 'error';
        this.isSubmitting = false;
      }
    });
  }
  
}