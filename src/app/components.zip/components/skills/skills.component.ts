import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Skill } from '../../models/portfolio.model';

@Component({
  selector: 'app-skills',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="skills" class="section-padding">
      <div class="container">
        <div class="row mb-5" data-aos="fade-up">
          <div class="col-12 text-center">
            <h2 class="display-5 mb-3 fw-bold">Technical <span class="text-accent">Skills</span></h2>
            <div class="underline mx-auto"></div>
          </div>
        </div>
        <div class="row g-4">
          <div *ngFor="let skill of skills; let i = index" class="col-6 col-md-4 col-lg-3" 
             
               data-aos="fade-up" [attr.data-aos-delay]="i * 100">
            <div class="skill-card glass-card p-4 text-center">
              <i class="bi {{skill.icon}} fs-1 mb-3 text-accent"></i>
              <h5 class="mb-2">{{skill.name}}</h5>
              <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-accent" [style.width.%]="skill.proficiency"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .text-accent { color: #00bcd4; }
    .bg-accent { background-color: #00bcd4; }
    .underline { width: 80px; height: 4px; background: #00bcd4; border-radius: 10px; }
    .skill-card {
      transition: all 0.3s ease;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      h5 { font-size: 1.1rem; }
      &:hover {
        transform: translateY(-10px);
        background: rgba(255, 255, 255, 0.15);
        box-shadow: 0 10px 20px rgba(0,0,0,0.2);
      }
    }
    .progress { background: rgba(255,255,255,0.1); }
    .progress { 
      background: rgba(255,255,255,0.1);
      overflow: visible;
    }
    .progress-bar {
      transition: width 1.5s ease-in-out;
    }
  `]
})
export class SkillsComponent {
  @Input() skills: Skill[] = [];
}