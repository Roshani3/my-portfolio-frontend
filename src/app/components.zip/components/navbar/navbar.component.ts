import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <nav class="navbar navbar-expand-lg fixed-top" [ngClass]="{'scrolled': isScrolled}">
      <div class="container">
        <a class="navbar-brand text-white" href="#">PORTFOLIO<span class="text-accent">.</span></a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
          <i class="bi bi-list text-white fs-1"></i>
        </button>
        <div class="collapse navbar-collapse" id="navContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item"><a class="nav-link px-3" href="#home">Home</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="#about">About</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="#skills">Skills</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="#experience">Experience</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="#projects">Projects</a></li>
            <li class="nav-item"><a class="nav-link px-3" href="#contact">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      transition: all 0.4s ease;
      padding: 20px 0;
      background: transparent;
    }
    .navbar.scrolled {
      padding: 12px 0;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(10px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    .nav-link {
      color: #f8fafc !important;
      font-weight: 500;
      font-size: 0.95rem;
      position: relative;
      &:after {
        content: '';
        position: absolute;
        width: 0;
        height: 2px;
        bottom: 5px;
        left: 15px;
        background-color: #00bcd4;
        transition: width 0.3s ease;
      }
      &:hover:after {
        width: calc(100% - 30px);
      }
    }
    .text-accent { color: #00bcd4; }
    .navbar-brand { font-size: 1.5rem; letter-spacing: 2px; }
  `]
})
export class NavbarComponent {
  isScrolled = false;

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.isScrolled = window.scrollY > 50;
  }
}
