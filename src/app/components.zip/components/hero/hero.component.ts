import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-hero',
  standalone: true,
  template: `
    <section id="home" class="hero-section d-flex align-items-center">
      <div class="container mt-5">
        <div class="row align-items-center">
          <div class="col-lg-7" data-aos="fade-right">
            <h5 class="text-accent mb-3 fw-semibold">Hi, my name is</h5>
            <h1 class="display-3 mb-2 text-white fw-bold">{{name}}</h1>
            <h2 class="display-5 text-light-muted mb-4">{{title}}</h2>
            <p class="lead mb-5 col-lg-10 text-light-muted lh-lg">
             I build scalable, enterprise-grade web applications with a strong focus on clean architecture, performance optimization, and seamless user experiences. Specializing in Angular and .NET Core.
            </p>
            <div class="d-flex gap-3">
              <a href="#projects" class="btn btn-custom btn-custom-primary px-5 py-3 fw-bold">View My Work</a>
              <a href="#contact" class="btn btn-custom btn-custom-outline px-5 py-3 fw-bold">Let's Connect</a>
            </div>
          </div>
          <!-- Professional Local Avatar Section -->
          <div class="col-lg-5 d-none d-lg-block" data-aos="zoom-in">
             <div class="hero-image-container">
               <div class="hero-image-wrapper">
                 <img src="assets/avatar4.jfif" 
                      alt="Professional Avatar" 
                      class="img-fluid rounded-4 shadow-2xl main-hero-img">
                 <div class="border-frame"></div>
               </div>
             </div>
          </div>
        </div>
      </div>
      <div class="scroll-indicator d-none d-md-block">
        <div class="mouse"></div>
      </div>
    </section>
  `,
  styles: [`
    .hero-section {
      min-height: 100vh;
      position: relative;
      background: radial-gradient(circle at top right, rgba(0, 188, 212, 0.12), transparent 40%),
                  radial-gradient(circle at bottom left, rgba(0, 188, 212, 0.05), transparent 30%);
    }
    .text-accent { color: #00bcd4; font-size: 1.25rem; }
    .text-light-muted { color: #cbd5e1; }
    
    .hero-image-container {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .hero-image-wrapper {
      position: relative;
      z-index: 1;
      width: 100%;
      max-width: 420px;
      
      .main-hero-img {
        position: relative;
        z-index: 2;
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        border: 2px solid rgba(0, 188, 212, 0.2);
        object-fit: cover;
        aspect-ratio: 1/1;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        background: rgba(255, 255, 255, 0.02);
      }

      .border-frame {
        position: absolute;
        top: 25px;
        left: 25px;
        width: 100%;
        height: 100%;
        border: 2px solid #00bcd4;
        border-radius: 1.5rem;
        z-index: 1;
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
      }

      &:hover {
        .main-hero-img {
          transform: translate(-15px, -15px);
          border-color: #00bcd4;
        }
        .border-frame {
          transform: translate(10px, 10px);
          background: rgba(0, 188, 212, 0.08);
        }
      }
    }

    .scroll-indicator {
      position: absolute;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%);
      .mouse {
        width: 32px;
        height: 52px;
        border: 2px solid rgba(255,255,255,0.2);
        border-radius: 20px;
        position: relative;
        &:after {
          content: '';
          position: absolute;
          width: 5px;
          height: 10px;
          background: #00bcd4;
          left: 50%;
          transform: translateX(-50%);
          bottom: 12px;
          border-radius: 2px;
          animation: scroll 2.2s cubic-bezier(0.15, 0.41, 0.69, 0.94) infinite;
        }
      }
    }
    @keyframes scroll {
      0% { transform: translate(-50%, 0); opacity: 1; }
      100% { transform: translate(-50%, 25px); opacity: 0; }
    }

    .btn-custom {
      border-radius: 12px;
      transition: all 0.3s ease;
      &:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.2); }
    }
  `]
})
export class HeroComponent {
  @Input() name: string = 'Roshani Patil';
  @Input() title: string = '';
}